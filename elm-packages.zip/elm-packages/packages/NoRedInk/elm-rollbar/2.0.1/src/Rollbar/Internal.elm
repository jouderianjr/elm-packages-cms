module Rollbar.Internal exposing (version)

{-| This module should not be publicly exposed.
-}


{-| Use tests to ensure this stays in sync with the version in elm.json!
-}
version : String
version =
    "2.0.0"
